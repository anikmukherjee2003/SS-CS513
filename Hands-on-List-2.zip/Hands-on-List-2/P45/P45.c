/*
 * P45 / P45.c
 * Revision notes:
 *   - This program belongs to the OS lab collection and is designed for
 *     revision, tracing, and debugging of a single Linux programming concept.
 *   - Program entry point for a focused operating-system exercise.
 *   - The code is intentionally kept compact and readable so the core
 *     system call flow, error handling, and resource cleanup are easy to
 *     follow during study or review.
 *   - Read the matching exercise description and README.md before changing
 *     behavior; the goal here is to preserve the teaching example while
 *     making it easier to revisit.
 *
 * Review checklist:
 *   - Confirm the call sequence and every return path.
 *   - Check all cleanup operations such as close(), unlink(), wait(), and
 *     IPC teardown before exiting.
 *   - Verify the signal, pipe, socket, or synchronization behavior against
 *     the expected operating-system model.
 */

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>

#define KEYFILE "/tmp/oslab_sysv_msgq_key"
/*
 * Main entry point for this exercise.
 * The function sets up the required resources, invokes the relevant OS
 * operation, checks return values, and cleans up before exiting.
 */
int main(void) {
    key_t k = ftok(KEYFILE, 'Q');
    if (k == (key_t)-1) {
        perror("ftok");
        return 1;
    }
    int id = msgget(k, 0);
    if (id == -1) {
        perror("msgget; run P41 first");
        return 1;
    }
    struct msqid_ds ds;
    if (msgctl(id, IPC_STAT, &ds) == -1) {
        perror("IPC_STAT");
        return 1;
    }
    printf("Old permission: %04o\n", ds.msg_perm.mode & 0777);
    ds.msg_perm.mode = (ds.msg_perm.mode & ~0777) | 0660;
    if (msgctl(id, IPC_SET, &ds) == -1) {
        perror("IPC_SET");
        return 1;
    }
    if (msgctl(id, IPC_STAT, &ds) == -1) {
        perror("IPC_STAT after update");
        return 1;
    }
    printf("New permission: %04o\n", ds.msg_perm.mode & 0777);
    return 0;
}
